# logMessageFormat

#### Members
--- 
- [ ] Jheremy Kevin Tancara Zambrana
--- 